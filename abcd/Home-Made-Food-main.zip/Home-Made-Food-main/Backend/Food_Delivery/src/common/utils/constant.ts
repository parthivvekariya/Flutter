export const SCALING_FACTOR = 100;
