export enum USER_TYPE {
  USER = 'USER',
  ADMIN = 'ADMIN',
}
